puts <<_MSG

You now need to download the Ext Javascript framework from

http://www.extjs.com/products/extjs/download.php

and unzip it into "#{RAILS_ROOT}/public/ext" if you have not done so yet.
The latest Ext version Ext_scaffold was tested against is 3.0.

_MSG
